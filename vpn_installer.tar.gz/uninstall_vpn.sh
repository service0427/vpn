#!/bin/bash

#====================================
# VPN 서버 완전 제거 스크립트
# - WireGuard 제거
# - API에서 서버 정보 삭제
# - 모든 설정 정리
#====================================

# 색상 정의
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

SERVER_IP=$(curl -s ifconfig.me)

echo -e "${RED}=====================================${NC}"
echo -e "${RED}   VPN 서버 완전 제거${NC}"
echo -e "${RED}=====================================${NC}"
echo
echo -e "${YELLOW}경고: 이 작업은 되돌릴 수 없습니다!${NC}"
echo -e "- WireGuard 제거"
echo -e "- API에서 서버 및 키 정보 삭제"
echo -e "- 모든 설정 파일 삭제"
echo
read -p "정말 계속하시겠습니까? (yes/no): " confirm

if [ "$confirm" != "yes" ]; then
    echo "취소되었습니다."
    exit 0
fi

echo

# 1. API에서 서버 정보 삭제
echo -e "${YELLOW}[1/4] API에서 서버 정보 삭제 중...${NC}"
if curl -s "http://220.121.120.83/vpn_api/release/all?ip=${SERVER_IP}&delete=true" | jq '.success' | grep -q true; then
    echo -e "${GREEN}✓ API에서 서버 정보 삭제 완료${NC}"
else
    echo -e "${RED}⚠ API 삭제 실패 (수동으로 처리 필요)${NC}"
fi

# 2. WireGuard 서비스 중지
echo -e "${YELLOW}[2/4] WireGuard 서비스 중지...${NC}"
systemctl stop wg-quick@wg0 2>/dev/null
systemctl disable wg-quick@wg0 2>/dev/null
wg-quick down wg0 2>/dev/null
echo -e "${GREEN}✓ WireGuard 서비스 중지 완료${NC}"

# 3. 설정 파일 삭제
echo -e "${YELLOW}[3/4] 설정 파일 삭제 중...${NC}"
rm -rf /etc/wireguard/
rm -f /home/vpn/vpn_server_data.json
rm -f /root/vpn_keys.json
echo -e "${GREEN}✓ 설정 파일 삭제 완료${NC}"

# 4. 방화벽 규칙 제거
echo -e "${YELLOW}[4/4] 방화벽 규칙 제거 중...${NC}"
VPN_PORT=$(grep -oP 'ListenPort\s*=\s*\K\d+' /etc/wireguard/wg0.conf 2>/dev/null || echo "55555")
firewall-cmd --permanent --remove-port=${VPN_PORT}/udp 2>/dev/null
firewall-cmd --permanent --remove-masquerade 2>/dev/null
firewall-cmd --reload 2>/dev/null
echo -e "${GREEN}✓ 방화벽 규칙 제거 완료${NC}"

echo
echo -e "${GREEN}=====================================${NC}"
echo -e "${GREEN}   VPN 서버 제거 완료!${NC}"
echo -e "${GREEN}=====================================${NC}"
echo
echo -e "${YELLOW}다음 단계:${NC}"
echo -e "1. 서버를 재설치하려면:"
echo -e "   ${GREEN}sudo ./install_vpn_server.sh${NC}"
echo
echo -e "2. WireGuard 패키지도 제거하려면:"
echo -e "   ${GREEN}dnf remove -y wireguard-tools${NC}"
echo